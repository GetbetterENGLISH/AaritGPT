const form = document.querySelector("#chat-form");
const input = document.querySelector("#message-input");
const messagesEl = document.querySelector("#messages");
const welcome = document.querySelector("#welcome");
const sendButton = document.querySelector("#send-button");
const statusEl = document.querySelector("#status");
const history = [];

function addMessage(role, content) {
  const row = document.createElement("div");
  row.className = `message ${role}`;
  if (role === "assistant") {
    const avatar = document.createElement("div");
    avatar.className = "avatar";
    avatar.textContent = "A";
    row.append(avatar);
  }
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = content;
  row.append(bubble);
  messagesEl.append(row);
  row.scrollIntoView({ behavior: "smooth", block: "nearest" });
  return bubble;
}

function fitInput() {
  input.style.height = "auto";
  input.style.height = `${Math.min(input.scrollHeight, 160)}px`;
}

input.addEventListener("input", fitInput);

async function sendMessage(text) {
  const content = text.trim();
  if (!content || sendButton.disabled) return;
  welcome.hidden = true;
  statusEl.textContent = "";
  history.push({ role: "user", content });
  addMessage("user", content);
  input.value = "";
  fitInput();
  sendButton.disabled = true;
  sendButton.setAttribute("aria-label", "AaritGPT is replying");
  const waitingBubble = addMessage("assistant", "Thinking…");

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ messages: history })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "AaritGPT could not reply.");
    waitingBubble.textContent = data.reply;
    history.push({ role: "assistant", content: data.reply });
    if (history.length > 12) history.splice(0, history.length - 12);
    statusEl.textContent = "";
  } catch (error) {
    waitingBubble.textContent = "I couldn’t answer that just now.";
    history.pop();
    statusEl.textContent = error.message || "Check your connection and try again.";
  } finally {
    sendButton.disabled = false;
    sendButton.setAttribute("aria-label", "Send message");
    input.focus();
  }
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  sendMessage(input.value);
});

input.addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    form.requestSubmit();
  }
});

document.querySelectorAll(".suggestion").forEach((button) => {
  button.addEventListener("click", () => sendMessage(button.dataset.prompt));
});

document.querySelector("#clear-chat").addEventListener("click", () => {
  history.length = 0;
  messagesEl.replaceChildren();
  welcome.hidden = false;
  statusEl.textContent = "";
  input.value = "";
  fitInput();
  input.focus();
});
