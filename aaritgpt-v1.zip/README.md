# AaritGPT v1

A responsive, black-and-white chat page plus a server-side Cloudflare Worker. Cloudflare serves the page and runs inference, so there is no AI API key in browser code. The chat history is held only in the page's JavaScript memory and is sent to the Worker with each message; it is not saved by this app. The browser's tab session is the lifetime of that in-memory history.

## What is included

- General questions and AaritUnblocked game/site help.
- A catalog that can be edited in `src/catalog.js`. Its initial list is only the games previously named: Cookie Clicker, Geometry Dash, Slither.io, Diep.io, Dig Out of Prison, AaritClicker, and Spiral Roll.
- A Worker AI binding, an 8-request-per-minute rate limit per source IP, message/history size limits, a public-safe assistant prompt, and input/output moderation with Llama Guard.
- Text-only rendering for replies, so model output is not interpreted as HTML.

The rate limit is a practical speed bump, not a strict global quota: Cloudflare documents it as approximate and local to its edge location. Visitors on the same network may share a public IP and therefore share that limit. A public site can still attract automated abuse; monitor usage and disable or tighten the chat if needed.

## Free usage

Cloudflare currently documents a daily free Workers AI allocation of 10,000 Neurons. The free Workers plan stops inference above the free allocation until the daily reset; the Workers Paid plan charges for usage above it. This implementation calls Llama Guard before and after each answer, so moderation uses some of that same daily AI allowance and makes replies slower. Limits, model availability, and provider terms can change. Avoid enabling paid overages unless the account owner intends to pay. This project does not use OpenAI, but you could change the backend to another provider later; many providers require an account and paid credits even when hosting is free.

## Deploy from a Chromebook

You will need a Cloudflare account and the Cloudflare Workers AI service enabled. Cloudflare may require account verification or a billing method for some features/models. No secret key is needed for the included Workers AI binding.

1. Put the `aaritgpt` folder in a GitHub repository (or upload it to a repository using github.com).
2. In the Cloudflare dashboard, open **Workers & Pages** and create a Worker from that GitHub repository. Use the repository root folder `aaritgpt` if the rest of the repository contains other files. The project uses `wrangler.jsonc`; deployment should build with `npm install` and publish with `npx wrangler deploy`.
3. If the dashboard build flow cannot deploy the Worker config, use Cloudflare's browser-based development environment or a local terminal and run `npm install`, `npx wrangler login`, then `npx wrangler deploy` in this folder. On Chromebook, a Linux terminal can run Node.js and npm.
4. Open the deployed `https://aaritgpt.<your-workers-subdomain>.workers.dev` address. Send a sample question and confirm the answer appears. Check Workers AI usage in the Cloudflare dashboard.
5. Keep the project on the Workers Free plan unless you knowingly choose paid usage. Do not enable paid upgrades as a workaround for the daily limit without reviewing the account's billing settings.

## Add it to Google Sites

1. Open the deployed `workers.dev` address and copy it.
2. In Google Sites, create a page named **AaritGPT**. This makes it appear in the site's navigation.
3. On that page choose **Insert → Embed → By URL**, paste the deployed address, and insert it. Resize the embed to be wide and tall enough for the chat. If Google Sites offers a **Full page embed**, that can also be used.
4. Publish the Google Site and verify the AaritGPT navigation link on the published site.

The Google Sites page itself is not changed by this project; its owner needs to add and publish the embed.

## Edit game knowledge

Edit the `games` array and `siteInfo` object in `src/catalog.js`, then redeploy. Only include games and site features that are actually confirmed on the site. The model will be told to say when it does not know a site-specific fact.

## Privacy and safety

- The app does not save or log chat messages. Conversation context is kept in page memory and disappears when that page session ends or **New chat** is clicked.
- Messages are transmitted to Cloudflare Workers AI to generate replies and are subject to Cloudflare's current service and privacy terms. The app cannot control provider-level processing.
- The app uses Cloudflare's request IP header only to calculate a one-way hash for rate limiting; it does not write that identifier to app storage.
- Do not ask visitors to provide passwords, school details, contact information, or other sensitive personal data.
- The model prompt asks for age-appropriate answers and safe refusals, but AI moderation is not perfect. For a public audience, review usage and the current provider policies regularly.

## Files

- `public/` — chat page, styles, and browser behavior
- `src/index.js` — request validation, rate limiting, prompt, and AI call
- `src/catalog.js` — editable game/site knowledge
- `wrangler.jsonc` — Cloudflare assets, AI, and rate-limit configuration
