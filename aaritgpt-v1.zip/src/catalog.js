// Edit these entries when the AaritUnblocked catalog changes.
export const games = [
  { name: "Cookie Clicker", description: "An incremental clicking game." },
  { name: "Geometry Dash", description: "A rhythm-based platform game." },
  { name: "Slither.io", description: "A multiplayer snake game." },
  { name: "Diep.io", description: "A multiplayer tank arena game." },
  { name: "Dig Out of Prison", description: "A prison escape digging game." },
  { name: "AaritClicker", description: "An AaritUnblocked clicker game." },
  { name: "Spiral Roll", description: "An arcade game about carving and rolling wood." }
];

// Add confirmed details about the site here. Keep unknown features out of this list.
export const siteInfo = {
  name: "AaritUnblocked",
  platform: "Google Sites",
  description: "A browser game website. Its game catalog is editable in src/catalog.js.",
  navigation: "Visitors can use the site's navigation menu to open its pages."
};
